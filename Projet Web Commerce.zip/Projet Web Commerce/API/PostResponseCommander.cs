﻿namespace Projet_Web_Commerce.API
{
    public class PostResponseCommander
    {
        public int NoAutorisation { get; set; }
        public string DateAutorisation { get; set; }
        public decimal FraisMarchand { get; set; }
        public string InfoSuppl {  get; set; }

    }
}
