﻿namespace Projet_Web_Commerce.API
{
    public class PostDataCommander
    {

        public int NoVendeur { get; set; }
        public string NomVendeur { get; set; }
        public long NoCarteCredit { get; set; }
        public string DateExpirationCarteCredit { get; set; }
        public decimal MontantPaiement { get; set; }
        public string NomPageRetour { get; set; }
        public string InfoSuppl { get; set; }

}
}
