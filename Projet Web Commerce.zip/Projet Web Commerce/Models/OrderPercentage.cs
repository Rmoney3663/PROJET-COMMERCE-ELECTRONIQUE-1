﻿namespace Projet_Web_Commerce.Models
{
    public class OrderPercentage
    {
        public int VendeurId { get; set; }
        public string VendeurName { get; set; }
        public decimal Percentage { get; set; }
    }
}
