﻿namespace Projet_Web_Commerce.Models
{
    public class ModelMoisAnnees
    {
        public int Mois { get; set; }
        public int Annee { get; set; }
    }
}
