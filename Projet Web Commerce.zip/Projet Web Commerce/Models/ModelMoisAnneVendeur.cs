﻿namespace Projet_Web_Commerce.Models
{
    public class ModelMoisAnneVendeur
    {
        public int VendeursCount { get; set; }
        public int Mois { get; set; }
        public int Annee { get; set; }
    }
}
