﻿namespace Projet_Web_Commerce.Models
{
    public class ModelMessages
    {

    }
}
