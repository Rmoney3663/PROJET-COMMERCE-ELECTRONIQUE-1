﻿namespace Projet_Web_Commerce.Models
{
    public class ModelVisite
    {
        public string ClientName { get; set; }
        public string VendeurName { get; set; }
        public int VisitCount { get; set; }
    }
}
