﻿namespace Projet_Web_Commerce.Models
{
    public class OrderPercentagesViewModel
    {
        public List<OrderPercentage> OrderPercentages { get; set; }
    }
}
