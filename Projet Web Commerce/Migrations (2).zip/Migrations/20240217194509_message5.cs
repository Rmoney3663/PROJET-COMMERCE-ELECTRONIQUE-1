﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projet_Web_Commerce.Migrations
{
    /// <inheritdoc />
    public partial class message5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur");
        }
    }
}
