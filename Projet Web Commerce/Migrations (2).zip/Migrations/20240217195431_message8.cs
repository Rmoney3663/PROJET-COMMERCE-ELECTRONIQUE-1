﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projet_Web_Commerce.Migrations
{
    /// <inheritdoc />
    public partial class message8 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage");

            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.AlterColumn<string>(
                name: "Transmetteur",
                table: "PPMessages",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur",
                unique: true,
                filter: "[Transmetteur] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage",
                column: "Destinataire",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage");

            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.AlterColumn<string>(
                name: "Transmetteur",
                table: "PPMessages",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur");

            migrationBuilder.AddForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage",
                column: "Destinataire",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
