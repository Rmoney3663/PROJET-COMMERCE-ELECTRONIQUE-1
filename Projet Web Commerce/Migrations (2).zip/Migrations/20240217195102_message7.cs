﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projet_Web_Commerce.Migrations
{
    /// <inheritdoc />
    public partial class message7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage");

            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur");

            migrationBuilder.AddForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage",
                column: "Destinataire",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage");

            migrationBuilder.DropIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages");

            migrationBuilder.CreateIndex(
                name: "IX_PPMessages_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_PPDestinatairesMessage_AspNetUsers_Destinataire",
                table: "PPDestinatairesMessage",
                column: "Destinataire",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
