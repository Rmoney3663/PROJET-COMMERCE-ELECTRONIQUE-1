﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Projet_Web_Commerce.Migrations
{
    /// <inheritdoc />
    public partial class message4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPMessages_AspNetUsers_Transmetteur",
                table: "PPMessages");

            migrationBuilder.AddForeignKey(
                name: "FK_PPMessages_AspNetUsers_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PPMessages_AspNetUsers_Transmetteur",
                table: "PPMessages");

            migrationBuilder.AddForeignKey(
                name: "FK_PPMessages_AspNetUsers_Transmetteur",
                table: "PPMessages",
                column: "Transmetteur",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
